import UIKit
import SwiftUI

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        
        // Criar a ContentView como interface inicial
        let contentView = ContentView()

        // Criar a janela com o scene
        window = UIWindow(windowScene: windowScene)
        
        // Definir o rootViewController para ser a ContentView dentro de UIHostingController
        window?.rootViewController = UIHostingController(rootView: contentView)
        
        // Tornar a janela visível
        window?.makeKeyAndVisible()
    }

    func sceneDidDisconnect(_ scene: UIScene) {}

    func sceneDidBecomeActive(_ scene: UIScene) {}

    func sceneWillResignActive(_ scene: UIScene) {}

    func sceneWillEnterForeground(_ scene: UIScene) {}

    func sceneDidEnterBackground(_ scene: UIScene) {}
}

