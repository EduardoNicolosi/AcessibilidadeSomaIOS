import UIKit
import SwiftUI

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Crie um UIHostingController com seu ContentView (SwiftUI)
        let contentView = ContentView()
        
        // Coloque o ContentView dentro de um UIHostingController
        let hostingController = UIHostingController(rootView: contentView)
        
        // Adicione o hosting controller como filho
        addChild(hostingController)
        
        // Defina a posição e tamanho do hosting controller
        hostingController.view.frame = view.bounds
        hostingController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
        // Adicione a view do hosting controller à hierarquia de views
        view.addSubview(hostingController.view)
        
        // Notifique o hosting controller que ele foi adicionado
        hostingController.didMove(toParent: self)
    }
}

